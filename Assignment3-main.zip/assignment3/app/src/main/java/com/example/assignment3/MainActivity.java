package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // initializing the spinners and the string arrays they're about to hold
        final Spinner spinnerState = findViewById(R.id.spinner_state);
        final Spinner spinnerCity = findViewById(R.id.spinner_city);
        String[] statesArr = {"Telangana", "Andhra Pradesh", "Tamil Nadu", "Karnataka"};
        String[][] citiesArr = {
                {"Hyderabad", "Warangal"},
                {"Amaravati", "Vishakapatnam"},
                {"Chennai", "Coimbatore"},
                {"Karnataka", "Bijapur"}
        };

        ArrayAdapter<String> states = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, statesArr);
        spinnerState.setAdapter(states);
        spinnerState.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            ArrayAdapter<String> cities;
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cities = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, citiesArr[position]);
                spinnerCity.setAdapter(cities);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        findViewById(R.id.button).setOnClickListener(v -> {
            validate();
        });
    }

    void validate(){
        EditText name = findViewById(R.id.name), email = findViewById(R.id.email);
        int[] stars = {R.id.star, R.id.star1};
        if (name.getText().toString().isEmpty() || email.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "Fill in the mandatory fields!", Toast.LENGTH_SHORT).show();
            for (int i : stars) {
                TextView t = findViewById(i);
                t.setText("*");
            }
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(email.getText()).matches())
            Toast.makeText(getApplicationContext(), "Invalid Email", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(getApplicationContext(), "All Correct!", Toast.LENGTH_SHORT).show();
    }
}